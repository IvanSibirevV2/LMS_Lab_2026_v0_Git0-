﻿namespace Queens2.Core
{
    public class Class1
    {

    }
}
