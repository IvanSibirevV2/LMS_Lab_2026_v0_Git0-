﻿namespace Queens2.Core.Models
{
    public class Queen
    {
        public int X { get; set; }

        public int Y { get; set; }

        public Queen(int x, int y)
        {
            X = x;
            Y = y;
        }

        public bool IsValidPosition()
        {
            return X >= 1 && X <= 8 && Y >= 1 && Y <= 8;
        }

        public bool IsSamePosition(Queen other)
        {
            return this.X == other.X && this.Y == other.Y;
        }
    }
}
