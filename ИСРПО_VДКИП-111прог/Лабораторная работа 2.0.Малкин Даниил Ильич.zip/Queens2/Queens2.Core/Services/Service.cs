﻿using Queens2.Core.Models;

namespace Queens2.Core.Services
{
    public class Service
    {
        public bool DoQueensAttackEachOther(Queen queen1, Queen queen2)
        {
            if (!queen1.IsValidPosition() || !queen2.IsValidPosition())
            {
                throw new ArgumentException("Координаты должны быть в диапазоне от 1 до 8");
            }

            if (queen1.IsSamePosition(queen2))
            {
                throw new ArgumentException("Два ферзя не могут стоять на одной клетке");
            }

            return queen1.X == queen2.X ||
                   queen1.Y == queen2.Y ||
                   Math.Abs(queen1.X - queen2.X) == Math.Abs(queen1.Y - queen2.Y);
        }

        public string GetAttackDescription(Queen queen1, Queen queen2)
        {
            try
            {
                bool attack = DoQueensAttackEachOther(queen1, queen2);
                return attack ? "Ферзи ДРУГ ДРУГА БЬЮТ!" : "Ферзи НЕ БЬЮТ друг друга";
            }
            catch (ArgumentException ex)
            {
                return ex.Message;
            }
        }
    }
}