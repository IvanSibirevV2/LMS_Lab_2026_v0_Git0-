﻿using System.Windows;
using Queens2.WPF.ViewModels;

namespace Queens2.WPF.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }
    }
}
