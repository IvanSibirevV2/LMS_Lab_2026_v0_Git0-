﻿using Queens2.Core.Models;
using Queens2.Core.Services;
using System.ComponentModel;
using System.Windows.Input;

namespace Queens2.WPF.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly Service _chessService;

        private string _x1 = "1";
        private string _y1 = "1";
        private string _x2 = "8";
        private string _y2 = "8";
        private string _resultText = "Введите координаты и нажмите 'Проверить'";
        private string _errorText = "";

        public MainViewModel()
        {
            _chessService = new Service();
        }

        public string X1
        {
            get => _x1;
            set { _x1 = value; OnPropertyChanged(nameof(X1)); }
        }

        public string Y1
        {
            get => _y1;
            set { _y1 = value; OnPropertyChanged(nameof(Y1)); }
        }

        public string X2
        {
            get => _x2;
            set { _x2 = value; OnPropertyChanged(nameof(X2)); }
        }

        public string Y2
        {
            get => _y2;
            set { _y2 = value; OnPropertyChanged(nameof(Y2)); }
        }

        public string ResultText
        {
            get => _resultText;
            set { _resultText = value; OnPropertyChanged(nameof(ResultText)); }
        }

        public string ErrorText
        {
            get => _errorText;
            set { _errorText = value; OnPropertyChanged(nameof(ErrorText)); }
        }

        private string _resultColor = "Black";

        public string ResultColor
        {
            get => _resultColor;
            set { _resultColor = value; OnPropertyChanged(nameof(ResultColor)); }
        }

        public ICommand CheckCommand => new RelayCommand(ExecuteCheck);

        private void ExecuteCheck(object parameter)
        {
            ErrorText = "";

            if (!int.TryParse(X1, out int x1))
            {
                ErrorText = "Ошибка: Вертикаль 1 - введите число";
                ResultText = "Ошибка ввода";
                return;
            }

            if (!int.TryParse(Y1, out int y1))
            {
                ErrorText = "Ошибка: Горизонталь 1 - введите число";
                ResultText = "Ошибка ввода";
                return;
            }

            if (!int.TryParse(X2, out int x2))
            {
                ErrorText = "Ошибка: Вертикаль 2 - введите число";
                ResultText = "Ошибка ввода";
                return;
            }

            if (!int.TryParse(Y2, out int y2))
            {
                ErrorText = "Ошибка: Горизонталь 2 - введите число";
                ResultText = "Ошибка ввода";
                return;
            }

            if (x1 < 1 || x1 > 8 || y1 < 1 || y1 > 8 ||
                x2 < 1 || x2 > 8 || y2 < 1 || y2 > 8)
            {
                ErrorText = "Ошибка: координаты должны быть от 1 до 8";
                ResultText = "Ошибка ввода";
                return;
            }

            if (x1 == x2 && y1 == y2)
            {
                ErrorText = "Ошибка: два ферзя не могут стоять на одной клетке";
                ResultText = "Ошибка ввода";
                return;
            }

            try
            {
                var queen1 = new Queen(x1, y1);
                var queen2 = new Queen(x2, y2);

                bool result = _chessService.DoQueensAttackEachOther(queen1, queen2);

                if (result)
                {
                    ResultText = "РЕЗУЛЬТАТ: Ферзи ДРУГ ДРУГА БЬЮТ!";
                    ResultColor = "Red";
                }
                else
                {
                    ResultText = "РЕЗУЛЬТАТ: Ферзи НЕ БЬЮТ друг друга";
                    ResultColor = "Green";
                }
            }
            catch (Exception ex)
            {
                ErrorText = ex.Message;
                ResultText = "Ошибка проверки";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute == null || _canExecute(parameter);

        public void Execute(object parameter) => _execute(parameter);

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}