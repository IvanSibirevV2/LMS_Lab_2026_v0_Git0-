
package com.example.lab08_storage;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.*;

public class MainActivity extends AppCompatActivity {
    private static final String TAG_INT = "Lab08_Internal";
    private static final String TAG_EXT = "Lab08_External";
    private static final String TAG_IO = "Lab08_IO";

    private static final String INT_FILE = "internal_data.txt";
    private static final String EXT_FILE = "external_data.txt";
    private static final String TEST_DIR = "Lab08_TestDir";

    private TextView tvLog;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvLog = findViewById(R.id.tvLog);

        findViewById(R.id.btnIntWrite).setOnClickListener(v -> writeInternal());
        findViewById(R.id.btnIntRead).setOnClickListener(v -> readInternal());
        findViewById(R.id.btnExtWrite).setOnClickListener(v -> writeExternal());
        findViewById(R.id.btnList).setOnClickListener(v -> listFiles());
        findViewById(R.id.btnCreateDir).setOnClickListener(v -> createDir());
        findViewById(R.id.btnDelete).setOnClickListener(v -> deleteFile());
    }

    // 📥 Внутренняя память: запись
    private void writeInternal() {
        File f = new File(getFilesDir(), INT_FILE);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            String text = "Внутренняя память: " + System.currentTimeMillis();
            fos.write(text.getBytes());
            fos.write("\n".getBytes());
            Log.i(TAG_INT, "Записано: " + f.getAbsolutePath());
            updateLog("✅ Внутр: файл создан");
        } catch (IOException e) {
            Log.e(TAG_IO, "writeInt: " + e.getMessage());
        }
    }

    // 📤 Внутренняя память: чтение
    private void readInternal() {
        File f = new File(getFilesDir(), INT_FILE);
        if (!f.exists()) { updateLog("❌ Внутр: файл не найден"); return; }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line, res = "";
            while ((line = br.readLine()) != null) res += line + "\n";
            Log.i(TAG_INT, "Прочитано: " + res.trim());
            updateLog("📖 Внутр: " + res.trim());
        } catch (IOException e) { Log.e(TAG_IO, "readInt: " + e.getMessage()); }
    }

    // 📥 Внешняя память (app-specific): запись
    private void writeExternal() {
        File f = new File(getExternalFilesDir(null), EXT_FILE);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write("Внешняя память: ".getBytes());
            fos.write(String.valueOf(System.currentTimeMillis()).getBytes());
            Log.i(TAG_EXT, "Записано: " + f.getAbsolutePath());
            updateLog("✅ Внешн: файл создан");
        } catch (IOException e) { Log.e(TAG_IO, "writeExt: " + e.getMessage()); }
    }

    // 📋 Список файлов во внутреннем хранилище
    private void listFiles() {
        File dir = getFilesDir();
        if (dir.isDirectory()) {
            File[] files = dir.listFiles(pathname -> pathname.isFile());
            StringBuilder sb = new StringBuilder("📂 Файлы:\n");
            if (files != null) for (File f : files) sb.append(" • ").append(f.getName()).append(" (").append(f.length()).append("B)\n");
            Log.d(TAG_INT, sb.toString());
            updateLog(sb.toString());
        }
    }

    // 📁 Создание папки
    private void createDir() {
        File newDir = new File(getFilesDir(), TEST_DIR);
        if (newDir.mkdirs()) {
            Log.i(TAG_INT, "Папка создана: " + newDir.getAbsolutePath());
            updateLog("📁 Папка создана");
        } else updateLog("⚠️ Папка уже существует или ошибка");
    }

    // 🗑 Удаление файла
    private void deleteFile() {
        File f = new File(getFilesDir(), INT_FILE);
        if (f.exists() && f.delete()) {
            Log.i(TAG_IO, "Файл удалён: " + f.getName());
            updateLog("🗑 Файл удалён");
        } else updateLog("❌ Удаление не удалось");
    }

    private void updateLog(String msg) {
        tvLog.setText(msg);
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}