package com.example.lab07_state;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private TextView tvStatus; private EditText etInput;
    private static final String TAG = "Lab07";
    private static final String FILE = "state.txt";
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvStatus = findViewById(R.id.tvStatus);
        etInput = findViewById(R.id.etInput);
        String saved = loadState();
        if (saved != null) { tvStatus.setText("Загружено: " + saved); etInput.setText(saved); }
        Log.i(TAG, "Приложение запущено");
    };
    public void onSaveClick(View v) {
        String data = etInput.getText().toString().trim();
        if (data.isEmpty()) { Log.w(TAG, "Пустой ввод"); return; }
        if (saveState(data)) { tvStatus.setText("Сохранено: " + data); Log.i(TAG, "Успешная запись"); }
        else { Log.e(TAG, "Ошибка записи"); }
    }

    private boolean saveState(String text) {
        try (FileOutputStream fos = new FileOutputStream(new File(getFilesDir(), FILE))) {
            fos.write(text.getBytes()); fos.write("\n".getBytes());
            return true;
        } catch (IOException e) { Log.e(TAG, "write: " + e.getMessage()); return false; }
    }

    private String loadState() {
        File f = new File(getFilesDir(), FILE);
        if (!f.exists()) { Log.d(TAG, "Файл не найден"); return null; }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            return br.readLine();
        } catch (IOException e) { Log.e(TAG, "read: " + e.getMessage()); return null; }
    }
    }
