package com.example.myapp; // замените на свой пакет

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView titleTextView;
    private Button refreshButton;
    private ListView listView;
    private CatAdapter adapter;
    private List<Integer> catImages; // список идентификаторов изображений

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация View
        titleTextView = findViewById(R.id.titleTextView);
        refreshButton = findViewById(R.id.refreshButton);
        listView = findViewById(R.id.listView);

        // Подготовка данных: список изображений
        catImages = new ArrayList<>();
        catImages.add(R.drawable.cat1);
        catImages.add(R.drawable.cat2);
        catImages.add(R.drawable.cat3);
        // Добавьте столько, сколько у вас есть изображений

        // Создаём адаптер
        adapter = new CatAdapter(catImages);
        listView.setAdapter(adapter);

        // Обработчик кнопки "Обновить"
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Пример действия: перемешиваем список или меняем порядок
                // Здесь можно реализовать, например, случайную перестановку
                // или загрузить новые картинки. Для демонстрации просто уведомляем адаптер об изменениях.
                // В реальности вы можете добавить новые изображения в catImages и вызвать adapter.notifyDataSetChanged()
                // Но для простоты оставим так:
                // adapter.notifyDataSetChanged(); // если данные не менялись, это не даст эффекта
                // Можно добавить случайный элемент:
                // catImages.add(R.drawable.cat_extra);
                // adapter.notifyDataSetChanged();
            }
        });
    }

    // Внутренний класс адаптера
    class CatAdapter extends BaseAdapter {

        private List<Integer> images;

        public CatAdapter(List<Integer> images) {
            this.images = images;
        }

        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public Object getItem(int position) {
            return images.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Оптимизация с использованием convertView и ViewHolder
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.list_item, parent, false);
                ViewHolder holder = new ViewHolder();
                holder.imageView = convertView.findViewById(R.id.catImageView);
                convertView.setTag(holder);
            }

            ViewHolder holder = (ViewHolder) convertView.getTag();
            // Устанавливаем изображение
            holder.imageView.setImageResource(images.get(position));

            return convertView;
        }

        // Класс для хранения ссылок на View (шаблон ViewHolder)
        class ViewHolder {
            ImageView imageView;
        }
    }
}